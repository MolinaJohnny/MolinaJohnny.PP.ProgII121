
package parcialjohnnymolina;


public class Libro extends Publicacion {
    
    private String Autor;
    private generoLibro generolibro;

    public Libro(String Autor, generoLibro generolibro, String Titulo, int AñoPublicacion) {
        super(Titulo, AñoPublicacion);
        this.Autor = Autor;
        this.generolibro = generolibro;
    }

    @Override
    public String toString() {
        return "Libro{" + "Autor=" + Autor + ", generolibro=" + generolibro + '}';
    }
    @Override
    public boolean sePuedeLeer(){
        return true;
    }


    public void Leer(){
        System.out.println("Se esta leyendo el Libro "+ Titulo);
    }
    
    
    
}
