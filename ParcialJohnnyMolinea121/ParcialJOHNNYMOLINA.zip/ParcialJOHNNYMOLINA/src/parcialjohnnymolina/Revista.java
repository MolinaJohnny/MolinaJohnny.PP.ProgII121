
package parcialjohnnymolina;


public class Revista extends Publicacion {
    
    private int NumeroEdicion;

    public Revista(int NumeroEdicion, String Titulo, int AñoPublicacion) {
        super(Titulo, AñoPublicacion);
        this.NumeroEdicion = NumeroEdicion;
    }

    @Override
    public String toString() {
        return "Revista{" + "NumeroEdicion=" + NumeroEdicion + '}';
    }
    @Override
    public boolean sePuedeLeer(){
        return true;
    }
    public void Leer(){
       
        System.out.println("Se esta leyendo la Revista " + Titulo);
    }
    
    
    
    
}
