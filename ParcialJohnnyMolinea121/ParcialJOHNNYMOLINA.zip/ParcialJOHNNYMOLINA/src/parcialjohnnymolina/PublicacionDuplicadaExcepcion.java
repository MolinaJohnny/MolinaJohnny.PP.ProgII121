
package parcialjohnnymolina;

/**
 *
 * @author aofbf
 */
public class PublicacionDuplicadaExcepcion extends Exception {
    public PublicacionDuplicadaExcepcion(String mensaje){
        super(mensaje);
    }
    
    
}
