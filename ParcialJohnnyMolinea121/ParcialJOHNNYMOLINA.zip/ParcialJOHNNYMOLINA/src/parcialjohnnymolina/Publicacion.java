
package parcialjohnnymolina;


public class Publicacion {
    
    public String Titulo;
    private int AñoPublicacion;

    public Publicacion(String Titulo, int AñoPublicacion) {
        this.Titulo = Titulo;
        this.AñoPublicacion = AñoPublicacion;
    }

    public boolean sePuedeLeer(){
        return false;
    }
    public String toString() {
        return "Publicacion{" + "Titulo=" + Titulo + ", A\u00f1oPublicacion=" + AñoPublicacion + '}';
    }

    public void setTitulo(String Titulo) {
        this.Titulo = Titulo;
    }

    public int getAñoPublicacion() {
        return AñoPublicacion;
    }

    public void setAñoPublicacion(int AñoPublicacion) {
        this.AñoPublicacion = AñoPublicacion;
    }
    
    
    
    
}
