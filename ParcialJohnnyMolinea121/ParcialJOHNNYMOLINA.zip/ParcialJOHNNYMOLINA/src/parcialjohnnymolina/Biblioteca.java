
package parcialjohnnymolina;

import java.util.ArrayList;


public class Biblioteca {
    private ArrayList<Publicacion> publicaciones;

    public Biblioteca() {
        
        publicaciones = new ArrayList<>();
    }
    
    public void agregarPublicacion(Publicacion publi) throws PublicacionDuplicadaExcepcion{
        if(publicaciones.contains(publi)){
            throw new PublicacionDuplicadaExcepcion("La publicacion ya existe con el titulo: "+ publi.Titulo);
        }
        else{
            publicaciones.add(publi);
        }
                
    }
    public void mostrarPublicaciones(){
        for (Publicacion p : publicaciones){
            System.out.println(p);}
    }
    public void leerPublicaciones(){
        for (Publicacion p : publicaciones){
            if(p.sePuedeLeer()){System.out.println("Se esta leyendo "+ p.Titulo);
            }
        
            else
                System.out.println("No se puede leer "+ p.Titulo);}
    }
    
    
}
