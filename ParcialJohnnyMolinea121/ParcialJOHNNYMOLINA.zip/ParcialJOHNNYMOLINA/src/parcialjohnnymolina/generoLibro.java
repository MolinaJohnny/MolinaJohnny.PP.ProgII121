
package parcialjohnnymolina;

/**
 *
 * @author aofbf
 */
public enum generoLibro {
    FICCION,
    NO_FICCION,
    CIENCIA,
    HISTORIA
}
