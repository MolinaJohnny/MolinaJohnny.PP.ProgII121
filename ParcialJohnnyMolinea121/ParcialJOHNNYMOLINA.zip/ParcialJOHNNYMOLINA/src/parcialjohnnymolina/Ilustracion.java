
package parcialjohnnymolina;

public class Ilustracion extends Publicacion {
    
    private String NombreAutor;
    private double Ancho;
    private double Alto;

    public Ilustracion(String NombreAutor, double Ancho, double Alto, String Titulo, int AñoPublicacion) {
        super(Titulo, AñoPublicacion);
        this.NombreAutor = NombreAutor;
        this.Ancho = Ancho;
        this.Alto = Alto;
    }
    @Override
    public boolean sePuedeLeer(){
        return false;
    }
    @Override
    public String toString() {
        return "Ilustracion{" + "NombreAutor=" + NombreAutor + ", Ancho=" + Ancho + ", Alto=" + Alto + '}';
    }
    
    
    
    
    
}
