
package parcialjohnnymolina;


public class ParcialJOHNNYMOLINA {


    public static void main(String[] args) throws PublicacionDuplicadaExcepcion {
        Biblioteca biblio = new Biblioteca();
        biblio.agregarPublicacion(new Libro("Leonardo", generoLibro.CIENCIA, "El perro", 1980));
        biblio.agregarPublicacion(new Libro("Leonardo", generoLibro.CIENCIA, "El perro", 1980));
        biblio.agregarPublicacion(new Revista(1 , "El gato", 1980));
        biblio.agregarPublicacion(new Ilustracion("Keke" , 190, 180, "La nutria", 1980));

        biblio.mostrarPublicaciones();
        biblio.leerPublicaciones();
        
    }
    
}
